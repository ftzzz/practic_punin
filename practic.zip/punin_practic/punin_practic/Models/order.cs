﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace punin_practic.Models
{
    public class order
    
    {
        [Key]
        public int order_id { get; set; }
        
        public int client_id { get; set; }
        public DateTime order_date { get; set; }
        public DateTime? due_date { get; set; }
        public int total_quantity { get; set; }
        // Связи
        public client clients { get; set; }
        public ICollection<payment> payments { get; set; }
    }
}
