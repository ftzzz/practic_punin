﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punin_practic.Models
{
    public class Role
    {
        public int roleid { get; set; }
        public string rolename { get; set; }
        public ICollection<User> users { get; set; }
    }
}
