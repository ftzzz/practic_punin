﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using punin_practic.Models;
using System.ComponentModel.DataAnnotations;

namespace punin_practic.Data;

public class PrintingServiceContext : DbContext
{
    public DbSet<client> clients { get; set; }
    public DbSet<order> orders { get; set; }
    public DbSet<payment> payments { get; set; }
    public DbSet<User> users { get; set; }
    public DbSet<Role> roles { get; set; }


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseNpgsql("Host=localhost;Database=postgres;Username=postgres;Password=prosta4oklolkek");
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        //Fluent API для настройки связей
        modelBuilder.Entity<order>()
            .HasOne(o => o.clients)
            .WithMany(c => c.orders) 
            .HasForeignKey(o => o.client_id);

        modelBuilder.Entity<User>()
            .HasOne(u => u.roles)
            .WithMany(r => r.users)
            .HasForeignKey(u => u.roleid);

    }

}
