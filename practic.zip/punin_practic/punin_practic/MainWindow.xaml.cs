﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Microsoft.EntityFrameworkCore;
using System.Windows.Shapes;
using punin_practic.Data;
using punin_practic.Models;

namespace punin_practic
{
    public partial class MainWindow : Window
    {
        private PrintingServiceContext _context = new PrintingServiceContext();
        private client _selectedClient;

        public MainWindow()
        {
            InitializeComponent();
            LoadClientsDataGrid();
        }

        private void LoadClientsDataGrid()
        {
            ClientsDataGrid.ItemsSource = _context.clients.ToList();
        }

        private void AddOrUpdateClient_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateClientData(first_nameTextBox.Text, last_nameTextBox.Text, emailTextBox.Text))
            {
                return;
            }

            try
            {
                if (_selectedClient != null)
                {
                    _selectedClient.first_name = first_nameTextBox.Text;
                    _selectedClient.last_name = last_nameTextBox.Text;
                    _selectedClient.email = emailTextBox.Text;
                    _selectedClient.phone = phoneTextBox.Text;
                    _selectedClient.address = addressTextBox.Text;

                    _context.SaveChanges();
                    _selectedClient = null;
                }
                else
                {
                    var client = new client
                    {
                        first_name = first_nameTextBox.Text,
                        last_name = last_nameTextBox.Text,
                        email = emailTextBox.Text,
                        phone = phoneTextBox.Text,
                        address = addressTextBox.Text
                    };

                    _context.clients.Add(client);
                    _context.SaveChanges();
                }

                LoadClientsDataGrid();
                MessageBox.Show("Изменения сохранены");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditClient_Click(object sender, RoutedEventArgs e)
        {
            if (ClientsDataGrid.SelectedItem is client selectedClient)
            {
                _selectedClient = selectedClient;

                first_nameTextBox.Text = selectedClient.first_name;
                last_nameTextBox.Text = selectedClient.last_name;
                emailTextBox.Text = selectedClient.email;
                phoneTextBox.Text = selectedClient.phone;
                addressTextBox.Text = selectedClient.address;
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента из списка");
            }
        }

        private void DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            if (ClientsDataGrid.SelectedItem is client selectedClient)
            {
                _context.clients.Remove(selectedClient);
                _context.SaveChanges();

                LoadClientsDataGrid();
                MessageBox.Show("Клиент удален");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента из списка");
            }
        }

        private bool ValidateClientData(string firstName, string lastName, string email)
        {
            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName) || string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Имя, фамилия и email не могут быть пустыми.");
                return false;
            }
            return true;
        }
    }
}