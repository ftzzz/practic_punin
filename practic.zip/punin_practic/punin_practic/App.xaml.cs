﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace punin_practic
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            ShowLoginWindow();
        }

        public void ShowLoginWindow()
        {
            var loginWindow = new LoginWindow();
            if (loginWindow.ShowDialog() == true)
            {
                var mainWindow = new MainWindow();
                mainWindow.Show();
            }
            else
            {
                Shutdown(); // Закрываем приложение, если вход не был успешен
            }
        }
    }
}


