﻿using Microsoft.EntityFrameworkCore;
using punin_practic.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace punin_practic
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public PrintingServiceContext _context;
        public LoginWindow()
        {
            InitializeComponent();
            _context = new PrintingServiceContext(); 
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password; 

            
            var user = _context.users
                               .Include(u => u.roles) 
                               .FirstOrDefault(u => u.username == username && u.password == password);
            
            if (user != null)
            {
                switch (user.roles.rolename) 
                {
                    case "Admin":
                        var mainWindow = new MainWindow(); 
                        mainWindow.ShowDialog();
                        break;
                    case "User":
                        var userWindow = new UserWindow();
                        userWindow.ShowDialog();
                        break;
                    default:
                        MessageBox.Show("Роль не определена.");
                        break;
                }
                this.Close(); 
            }
            else
            {
                MessageBox.Show("Неверное имя пользователя или пароль.");
            }
        }
    }
}
